package menu;

public interface Navigator {
    void navigate();
}
